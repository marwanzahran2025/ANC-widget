package com.example.ancwidget

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import java.util.UUID

object SoundcoreLink {
    // Mode values read from the capture. Normal (1) is a guess: use the test buttons to confirm.
    val MODES = linkedMapOf("ANC" to 0, "Adaptive" to 3, "Transparency" to 2, "Normal" to 1)

    private val UUIDS = listOf("0205f5da", "55aaf5da").map { UUID.fromString("$it-0000-1000-8000-00805f9b34fb") } +
        UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")

    fun frame(mode: Int): ByteArray {
        val b = intArrayOf(0x08, 0xEE, 0, 0, 0, 0x06, 0x81, 0x11, 0, mode, 0, 0, 0x05, 0x11, 0, 0)
        val sum = b.sum() and 0xFF
        return (b.toList() + sum).map { it.toByte() }.toByteArray()
    }

    fun address(ctx: Context): String? = ctx.getSharedPreferences("p", 0).getString("addr", null)
    fun saveAddress(ctx: Context, a: String) = ctx.getSharedPreferences("p", 0).edit().putString("addr", a).apply()

    @SuppressLint("MissingPermission")
    fun send(ctx: Context, mode: Int): String = try { doSend(ctx, mode) } catch (e: Throwable) { "Error: " + e.message }

    @SuppressLint("MissingPermission")
    private fun doSend(ctx: Context, mode: Int): String {
        val addr = address(ctx) ?: return "Open the app and pick your earbuds first"
        val adapter = ctx.getSystemService(BluetoothManager::class.java).adapter
        if (adapter == null || !adapter.isEnabled) return "Bluetooth is off"
        val device = adapter.getRemoteDevice(addr)
        var err = "Could not connect"
        for (u in UUIDS) {
            try {
                val s = device.createRfcommSocketToServiceRecord(u)
                s.connect()
                s.outputStream.write(frame(mode))
                s.outputStream.flush()
                Thread.sleep(400)
                s.close()
                return "Sent"
            } catch (e: Exception) { err = e.message ?: err }
        }
        return err
    }
}
