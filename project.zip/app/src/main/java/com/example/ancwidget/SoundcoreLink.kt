package com.example.ancwidget

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import java.util.UUID

object SoundcoreLink {
    // Mode values confirmed on the real earbuds.
    val MODES = linkedMapOf("Noise Cancellation" to 0, "Adaptive" to 3, "Normal" to 2, "Transparency" to 1)

    // Found in your capture: the earbuds advertise this service on RFCOMM channel 15, and the Soundcore app talks to it.
    private val UUIDS = listOf(UUID.fromString("0cf12d31-fac3-4553-bd80-d6832e7b3956"))

    fun frame(mode: Int): ByteArray {
        val b = intArrayOf(0x08, 0xEE, 0, 0, 0, 0x06, 0x81, 0x11, 0, mode, 0, 0, 0x05, 0x11, 0, 0)
        val sum = b.sum() and 0xFF
        return (b.toList() + sum).map { it.toByte() }.toByteArray()
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("p", 0)
    fun setAddress(ctx: Context, a: String?) = prefs(ctx).edit().apply { if (a == null) remove("addr") else putString("addr", a) }.apply()

    @SuppressLint("MissingPermission")
    fun resolveAddress(ctx: Context): String? {
        prefs(ctx).getString("addr", null)?.let { return it }
        return try {
            val list = ctx.getSystemService(BluetoothManager::class.java).adapter.bondedDevices
                .filter { it.name.orEmpty().contains("liberty", true) || it.name.orEmpty().contains("soundcore", true) }
            (list.firstOrNull { it.name.orEmpty().contains("liberty 5", true) } ?: list.firstOrNull())?.address
        } catch (e: Exception) { null }
    }

    @SuppressLint("MissingPermission")
    fun deviceName(ctx: Context): String? = try {
        resolveAddress(ctx)?.let { ctx.getSystemService(BluetoothManager::class.java).adapter.getRemoteDevice(it).name }
    } catch (e: Exception) { null }

    @SuppressLint("MissingPermission")
    fun send(ctx: Context, mode: Int): String = try { doSend(ctx, mode) } catch (e: Throwable) { "Error: " + e.message }

    private fun ByteArray.hex() = joinToString("") { "%02x".format(it) }

    private fun readUntil(s: BluetoothSocket, ms: Long, marker: String): String {
        val end = System.currentTimeMillis() + ms
        val out = java.io.ByteArrayOutputStream()
        while (System.currentTimeMillis() < end) {
            val n = s.inputStream.available()
            if (n > 0) {
                val buf = ByteArray(n)
                out.write(buf, 0, s.inputStream.read(buf))
                if (marker.isNotEmpty() && out.toByteArray().hex().contains(marker)) break
            } else Thread.sleep(50)
        }
        return out.toByteArray().hex()
    }

    @SuppressLint("MissingPermission")
    private fun doSend(ctx: Context, mode: Int): String {
        val addr = resolveAddress(ctx) ?: return "No Liberty earbuds found. Pair them first, or pick a device in the app"
        val adapter = ctx.getSystemService(BluetoothManager::class.java).adapter
        if (adapter == null || !adapter.isEnabled) return "Bluetooth is off"
        val device = adapter.getRemoteDevice(addr)
        val info = intArrayOf(0x08, 0xEE, 0, 0, 0, 0x01, 0x01, 0x0A, 0x00, 0x02).map { it.toByte() }.toByteArray()
        val log = StringBuilder()
        for (insecure in listOf(false, true)) for (u in UUIDS) {
            val tag = u.toString().substring(0, 8) + (if (insecure) "/insecure" else "")
            try {
                val sock = if (insecure) device.createInsecureRfcommSocketToServiceRecord(u) else device.createRfcommSocketToServiceRecord(u)
                sock.connect()
                sock.outputStream.write(info); sock.outputStream.flush()
                readUntil(sock, 700, "")
                sock.outputStream.write(frame(mode)); sock.outputStream.flush()
                val r = readUntil(sock, 1500, "09ff0000010681")
                sock.close()
                if (r.contains("09ff0000010681")) { ctx.getSharedPreferences("p", 0).edit().putInt("mode", mode).apply(); AncWidget.refresh(ctx); return "OK, earbuds confirmed ($tag)" }
                log.append("$tag: connected, no reply (got ${r.take(40)}). ")
            } catch (e: Exception) { log.append("$tag: ${e.message}. ") }
        }
        return log.toString()
    }
}
