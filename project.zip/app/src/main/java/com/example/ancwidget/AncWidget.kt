package com.example.ancwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import kotlin.concurrent.thread

class AncWidget : AppWidgetProvider() {
    companion object {
        private val MODES = intArrayOf(0, 3, 2, 1)
        private val CELLS = intArrayOf(R.id.c0, R.id.c1, R.id.c2, R.id.c3)
        private val ICONS = intArrayOf(R.id.i0, R.id.i1, R.id.i2, R.id.i3)
        private val LABELS = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3)
        private val SEPS = intArrayOf(R.id.s1, R.id.s2, R.id.s3)

        fun build(ctx: Context): RemoteViews {
            val p = ctx.getSharedPreferences("p", 0)
            val ai = MODES.indexOf(p.getInt("mode", -1))
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            v.setFloat(R.id.root, "setAlpha", 1f - p.getInt("alpha", 0).coerceIn(0, 80) / 100f)
            MODES.forEachIndexed { i, mode ->
                val intent = Intent(ctx, AncWidget::class.java).setAction("SET").putExtra("mode", mode)
                val pi = PendingIntent.getBroadcast(ctx, mode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                v.setOnClickPendingIntent(CELLS[i], pi)
                v.setOnClickPendingIntent(LABELS[i], pi)
                val on = i == ai
                v.setInt(CELLS[i], "setBackgroundResource", if (on) R.drawable.tile_on else R.drawable.tile_off)
                v.setInt(ICONS[i], "setColorFilter", if (on) 0xFFFFFFFF.toInt() else 0xFF9D9D9F.toInt())
                v.setTextColor(LABELS[i], if (on) 0xFFFFFFFF.toInt() else 0xFF8E8E90.toInt())
            }
            SEPS.forEachIndexed { k, id -> v.setViewVisibility(id, if (ai == k || ai == k + 1) View.INVISIBLE else View.VISIBLE) }
            return v
        }

        fun refresh(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, AncWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, build(ctx))
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = mgr.updateAppWidget(ids, build(ctx))

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action != "SET") return
        val mode = intent.getIntExtra("mode", 0)
        val pr = goAsync()
        thread {
            val r = SoundcoreLink.send(ctx, mode)
            if (!r.startsWith("OK")) Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, r, Toast.LENGTH_LONG).show() }
            pr.finish()
        }
    }
}
