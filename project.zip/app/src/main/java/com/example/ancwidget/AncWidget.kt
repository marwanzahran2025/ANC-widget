package com.example.ancwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import android.widget.Toast
import kotlin.concurrent.thread

class AncWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val v = RemoteViews(ctx.packageName, R.layout.widget)
        listOf(R.id.b_anc to 0, R.id.b_adaptive to 3, R.id.b_trans to 2, R.id.b_normal to 1).forEach { (id, mode) ->
            val i = Intent(ctx, AncWidget::class.java).setAction("SET").putExtra("mode", mode)
            v.setOnClickPendingIntent(id, PendingIntent.getBroadcast(ctx, mode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }
        mgr.updateAppWidget(ids, v)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action != "SET") return
        val mode = intent.getIntExtra("mode", 0)
        val pr = goAsync()
        thread {
            val r = SoundcoreLink.send(ctx, mode)
            Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, r, Toast.LENGTH_SHORT).show() }
            pr.finish()
        }
    }
}
