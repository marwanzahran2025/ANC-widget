package com.example.ancwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import android.widget.Toast
import kotlin.concurrent.thread

class AncWidget : AppWidgetProvider() {
    companion object {
        private val CELLS = listOf(R.id.c_anc to 0, R.id.c_adaptive to 3, R.id.c_normal to 2, R.id.c_trans to 1)

        fun build(ctx: Context): RemoteViews {
            val active = ctx.getSharedPreferences("p", 0).getInt("mode", -1)
            val v = RemoteViews(ctx.packageName, R.layout.widget)
            CELLS.forEach { (id, mode) ->
                val i = Intent(ctx, AncWidget::class.java).setAction("SET").putExtra("mode", mode)
                v.setOnClickPendingIntent(id, PendingIntent.getBroadcast(ctx, mode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                val on = mode == active
                v.setInt(id, "setBackgroundResource", if (on) R.drawable.cell_on else R.drawable.cell_off)
                v.setTextColor(id, if (on) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
            }
            return v
        }

        fun refresh(ctx: Context) {
            val m = AppWidgetManager.getInstance(ctx)
            val ids = m.getAppWidgetIds(ComponentName(ctx, AncWidget::class.java))
            if (ids.isNotEmpty()) m.updateAppWidget(ids, build(ctx))
        }
    }

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) = mgr.updateAppWidget(ids, build(ctx))

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action != "SET") return
        val mode = intent.getIntExtra("mode", 0)
        val pr = goAsync()
        thread {
            val r = SoundcoreLink.send(ctx, mode)
            if (!r.startsWith("OK")) Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, r, Toast.LENGTH_LONG).show() }
            pr.finish()
        }
    }
}
