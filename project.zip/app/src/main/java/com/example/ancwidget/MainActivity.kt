package com.example.ancwidget

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var box: LinearLayout

    @SuppressLint("MissingPermission")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        setContentView(ScrollView(this).apply { addView(box) })
        status = TextView(this)
        draw()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) = draw()

    @SuppressLint("MissingPermission")
    private fun draw() {
        box.removeAllViews()
        box.addView(TextView(this).apply { text = "1. Pick your earbuds (must be paired)"; textSize = 18f })
        try {
            val a = getSystemService(BluetoothManager::class.java).adapter
            a.bondedDevices.forEach { d ->
                box.addView(Button(this).apply {
                    text = d.name + (if (d.address == SoundcoreLink.address(this@MainActivity)) "  ✓" else "")
                    setOnClickListener { SoundcoreLink.saveAddress(this@MainActivity, d.address); draw() }
                })
            }
        } catch (e: Exception) { box.addView(TextView(this).apply { text = "Allow Bluetooth permission, then reopen" }) }
        box.addView(TextView(this).apply { text = "\n2. Test each mode (earbuds connected)"; textSize = 18f })
        SoundcoreLink.MODES.forEach { (name, m) ->
            box.addView(Button(this).apply {
                text = "$name  (value $m)"
                setOnClickListener {
                    status.text = "Sending..."
                    thread { val r = SoundcoreLink.send(this@MainActivity, m); runOnUiThread { status.text = r } }
                }
            })
        }
        box.addView(status)
        box.addView(TextView(this).apply { text = "\n3. Long-press your home screen, add the 'ANC Widget'." })
    }
}
