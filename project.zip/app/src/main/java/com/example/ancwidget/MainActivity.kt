package com.example.ancwidget

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.bluetooth.BluetoothManager
import android.content.ComponentName
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val CARD = 0xFF1B1E20.toInt()
    private val STRIP = 0xFF2D2D2F.toInt()
    private val GRAY = 0xFF8E8E90.toInt()
    private val BLUE = 0xFF00C9EC.toInt()
    private val ORDER = listOf(
        Triple("Noise Cancellation", 0, R.drawable.ic_nc), Triple("Adaptive", 3, R.drawable.ic_ad),
        Triple("Normal", 2, R.drawable.ic_nm), Triple("Transparency", 1, R.drawable.ic_tr))
    private lateinit var status: TextView
    private lateinit var deviceSub: TextView
    private lateinit var deviceRowSub: TextView
    private val tiles = ArrayList<FrameLayout>()
    private val icons = ArrayList<ImageView>()
    private val labels = ArrayList<TextView>()
    private val seps = ArrayList<View>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, size: Float, color: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = size; setTextColor(color) }
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)

    private fun row(title: String, sub: TextView?, click: () -> Unit): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, dp(14)); setOnClickListener { click() } }
        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mid.addView(tv(title, 16f))
        if (sub != null) mid.addView(sub)
        r.addView(mid, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(tv("\u203A", 22f, GRAY))
        return r
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(40), dp(16), dp(24)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })

        col.addView(tv("Liberty 5 Pro", 24f).apply { gravity = Gravity.CENTER })
        deviceSub = tv("", 13f, GRAY).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(20)) }
        col.addView(deviceSub)

        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = box(CARD, 24); setPadding(dp(12), dp(16), dp(12), dp(16)) }
        card.addView(tv("Ambient Sound", 16f).apply { setPadding(dp(6), 0, 0, dp(14)) })
        val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = box(STRIP, 16); setPadding(dp(5), dp(5), dp(5), dp(5)) }
        ORDER.forEachIndexed { i, (_, mode, icon) ->
            if (i > 0) {
                val s = View(this).apply { setBackgroundColor(0xFF4D4D50.toInt()) }
                seps.add(s); strip.addView(s, lp(dp(1), dp(30)))
            }
            val img = ImageView(this).apply { setImageResource(icon) }
            val tile = FrameLayout(this).apply {
                addView(img, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
                setOnClickListener { setMode(mode) }
            }
            icons.add(img); tiles.add(tile); strip.addView(tile, lp(0, dp(60), 1f))
        }
        card.addView(strip, lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(70)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
        ORDER.forEach { (name, mode, _) ->
            val t = tv(name, 12f, GRAY).apply { gravity = Gravity.CENTER; setOnClickListener { setMode(mode) } }
            labels.add(t); names.addView(t, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        card.addView(names)
        status = tv("", 12f, GRAY).apply { setPadding(dp(6), dp(14), 0, 0) }
        card.addView(status)
        col.addView(card)

        val prefs = getSharedPreferences("p", 0)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = box(CARD, 24); setPadding(dp(16), dp(4), dp(16), dp(4)) }
        rows.addView(row("Add widget to home screen", null) { addWidget() })
        val sl = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(14), 0, dp(10)) }
        val slLabel = tv("", 16f)
        val bar = SeekBar(this).apply {
            max = 80
            progress = prefs.getInt("alpha", 0).coerceIn(0, 80)
            progressTintList = ColorStateList.valueOf(BLUE)
            thumbTintList = ColorStateList.valueOf(BLUE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    slLabel.text = "Widget transparency: $p%"
                    prefs.edit().putInt("alpha", p).apply()
                    AncWidget.refresh(this@MainActivity)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        slLabel.text = "Widget transparency: ${bar.progress}%"
        sl.addView(slLabel); sl.addView(bar)
        rows.addView(sl)
        deviceRowSub = tv("", 12f, GRAY)
        rows.addView(row("Device", deviceRowSub) { pickDevice() })
        col.addView(rows, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(12) })

        refreshDevice(); refreshModeUi()
    }

    override fun onResume() { super.onResume(); refreshDevice(); refreshModeUi() }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) = refreshDevice()

    private fun refreshDevice() {
        val n = SoundcoreLink.deviceName(this)
        deviceSub.text = n ?: "No Liberty earbuds found. Pair them first"
        deviceRowSub.text = n ?: "None selected"
    }

    private fun refreshModeUi() {
        val ai = ORDER.indexOfFirst { it.second == getSharedPreferences("p", 0).getInt("mode", -1) }
        ORDER.forEachIndexed { i, _ ->
            val on = i == ai
            tiles[i].background = if (on) box(BLUE, 12) else null
            icons[i].setColorFilter(if (on) Color.WHITE else 0xFF9D9D9F.toInt())
            labels[i].setTextColor(if (on) Color.WHITE else GRAY)
        }
        seps.forEachIndexed { k, s -> s.visibility = if (ai == k || ai == k + 1) View.INVISIBLE else View.VISIBLE }
    }

    private fun setMode(mode: Int) {
        status.text = "Sending..."
        thread {
            val r = SoundcoreLink.send(this, mode)
            runOnUiThread { status.text = if (r.startsWith("OK")) "Earbuds confirmed" else r; refreshModeUi() }
        }
    }

    private fun addWidget() {
        val m = AppWidgetManager.getInstance(this)
        if (m.isRequestPinAppWidgetSupported) m.requestPinAppWidget(ComponentName(this, AncWidget::class.java), null, null)
        else Toast.makeText(this, "Long-press your home screen, tap Widgets, and add ANC Widget", Toast.LENGTH_LONG).show()
    }

    @SuppressLint("MissingPermission")
    private fun pickDevice() {
        val list = try { getSystemService(BluetoothManager::class.java).adapter.bondedDevices.toList() } catch (e: Exception) { emptyList() }
        val items = (listOf("Automatic (Liberty / Soundcore)") + list.map { it.name ?: it.address }).toTypedArray()
        AlertDialog.Builder(this).setTitle("Device").setItems(items) { _, i ->
            SoundcoreLink.setAddress(this, if (i == 0) null else list[i - 1].address)
            refreshDevice()
        }.show()
    }
}
